export const getApps = async( category ) => {
    const url = `http://localhost:3000/apps?limit=10&&offset=10`;
    const resp = await fetch( url );
    const { items } = await resp.json();
    const apps = items.map( app => ({
        id: app.app_id,
        title: app.app_name,
        url: app.app_image,
        description: app.app_description,
        price: validatePrice(app.app_price),
        status: app.app_status
    }));
    
    return apps;
}

function validatePrice(price) {
    
    if(price < 0.5){
        return 'FREE'
    } else {
       return  "$"+price;
    }
}