import { React, useState } from "react";
import PropTypes from "prop-types";
import Modal from "react-bootstrap/Modal";
import Card from "react-bootstrap/Card";
import Button from "react-bootstrap/Button";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Coments from '../components/Coments'
export const AppItem = ({comments, price, description, title, url, id }) => {
  const [isHover, setIsHover] = useState(false);
  const [smShow, setSmShow] = useState(false);
 console.log(comments)
  const handleMouseEnter = () => {
    setIsHover(true);
  };
  const handleMouseLeave = () => {
    setIsHover(false);
  };

  const hoverStyle = {
    backgroundColor: isHover ? "orange" : "white",
  };
  return (
    <>
      <div className="mt-2">
        <div
          className="card"
          style={hoverStyle}
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
          onClick={() => setSmShow(true)}
        >
          <img
            className="img-app"
            src={"../../public/app-icons/" + url}
            alt={title}
          />
          <div className="card-body">
            <h6 className="card-title">{title}</h6>
            <span className="card-text">{description}</span>
            <div className="small-ratings">
              <i className="fa fa-star rating-color"></i>
              <i className="fa fa-star rating-color"></i>
              <i className="fa fa-star rating-color"></i>
              <i className="fa fa-star"></i>
              <i className="fa fa-star"></i>
            </div>
            <span className="price">{price}</span>
          </div>
          <Modal
            size="sm"
            show={smShow}
            onHide={() => setSmShow(false)}
            aria-labelledby="example-modal-sizes-title-sm"
          >
            <Modal.Header closeButton>
              <Modal.Title id="example-modal-sizes-title-sm"></Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Card>
                <Card.Body>
                  <Row>
                    <Col>
                      <img
                        className="img-app-datail"
                        src={"../../public/app-icons/" + url}
                        alt={title}
                      />
                    </Col>
                    <Col>
                      <Card.Title>{title}</Card.Title>
                      <Card.Text>
                        Some quick example text to build on the card title and
                        make up the bulk of the card's content.
                      </Card.Text>
                      <span className="price">{price}</span>
                    </Col>
                  </Row>
                  <hr></hr>
                  <Coments key={comments}/>
                </Card.Body>
              </Card>
            </Modal.Body>
          </Modal>
        </div>
      </div>
    </>
  );
};

AppItem.propTypes = {
  title: PropTypes.string.isRequired,
  url: PropTypes.string.isRequired,
};
