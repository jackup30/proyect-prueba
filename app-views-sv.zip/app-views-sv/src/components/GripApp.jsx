import PropTypes from 'prop-types';

import { AppItem } from './AppItem';
import { useFetchApps } from '../hooks/useFetchApp';
import {Category} from '../components/Category'

export const GridApp = ({ category }) => {

    const { apps, isLoading } = useFetchApps( category );
    
    return (
        <>
            <h3>{ category }</h3>
            {
                isLoading && ( <h2>Cargando...</h2> )
            }
           
            <div className="container">
            <div className="row">
                {
                    apps.map( ( app ) => (
                        <AppItem  
                            key={ app.id } 
                            { ...app }
                        />
                    ))
                }
                
            </div>
            </div>

        </>
    )
}


// GridApp.propTypes = {
//     category: PropTypes.string.isRequired,
// }