import React from 'react'

export const Header = () => {
  
  return (
    <header>
    <div className="navbar bg-custom">
      <ul className="navbar-nav mr-auto">
      <li className="nav-item">
      <a className="nav-link" href="#"> <img src={"../../public/logo.png"} /></a>
      </li>
      </ul>
      <form className="form-inline my-2 my-lg-0">
        <input className="form-control mr-sm-2" type="search" />
         <button className="btn btn-outline-warning my-2 my-sm-0" type="submit"><i className="fa fa-search" aria-hidden="true"></i></button>
       </form>
    </div>
  </header>

  )
}
