import React from 'react'

function Coments({coments}) {
  return (
    <div className="container">
            <div className="row">
                {
                    coments
                }
            </div>
            </div>
  )
}

export default Coments