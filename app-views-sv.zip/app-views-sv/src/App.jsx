import React from 'react'
import { Header, GridApp } from './components';
export const App = () => {
  return (
    <>
    <Header/>
    <GridApp />
    </>
  )
}
