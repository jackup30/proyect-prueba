

import { useEffect, useState } from 'react';
import { getApps } from '../helpers/apiRequest';

export const useFetchApps = ( category ) => {
 
    const [apps, setApps] = useState([]);
    const [isLoading, setIsLoading] = useState( true );

    const getDts = async() => {
        const apps = await getApps( category );
        setApps(apps);
        setIsLoading(false);
    }
    
    useEffect( () => {
        getDts();
    }, []);



    return {
        apps,
        isLoading
    }

}