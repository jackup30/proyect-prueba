import {Module} from '@nestjs/common';
import {LoggerModule} from './core/logger/logger.module';
import {ExceptionsModule} from './core/exceptions/exceptions.module';
import {EnvironmentConfigModule} from './core/config/environment-config/environment-config.module';
import {SequelizeDatabaseModule} from "./core/database/sequelize/sequelize_database.module";
import { ApplicationModule } from './modules/applications/application.module';
import { ConfigModule } from '@nestjs/config';

@Module({
    imports: [
        LoggerModule,
        ExceptionsModule,
        EnvironmentConfigModule,
        SequelizeDatabaseModule,
        ApplicationModule,
        ConfigModule.forRoot(),
        
    ],
    controllers: [],
    providers: []
})
export class AppModule {}
