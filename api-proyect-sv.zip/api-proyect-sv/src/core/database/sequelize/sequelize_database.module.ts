import {Module} from '@nestjs/common';
import {SequelizeModule} from '@nestjs/sequelize';
import {EnvironmentConfigModule} from "../../config/environment-config/environment-config.module";
import {EnvironmentConfigService} from "../../config/environment-config/environment-config.service";
import {SequelizeConfig} from "./sequelize.config";

@Module({
    imports: [
        SequelizeModule.forRootAsync({
            imports: [EnvironmentConfigModule],
            inject: [EnvironmentConfigService],
            useFactory: SequelizeConfig
        })
    ]
})
export class SequelizeDatabaseModule {
}
