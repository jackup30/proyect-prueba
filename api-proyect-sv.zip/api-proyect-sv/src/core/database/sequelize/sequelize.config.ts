import {
    SequelizeModuleOptions
} from "@nestjs/sequelize/dist/interfaces/sequelize-options.interface";
import {EnvironmentConfigService} from "../../config/environment-config/environment-config.service";

export const SequelizeConfig = (config: EnvironmentConfigService) : SequelizeModuleOptions => ({
    dialect: 'mysql',
    host: config.getDatabaseHost(),
    port: config.getDatabasePort(),
    username: config.getDatabaseUser(),
    password: config.getDatabasePassword(),
    database: config.getDatabaseName(),
    autoLoadModels: true,
    synchronize: config.getDatabaseSync()
} as SequelizeModuleOptions);