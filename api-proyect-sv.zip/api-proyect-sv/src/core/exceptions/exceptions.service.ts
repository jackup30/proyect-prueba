import {
    BadRequestException,
    ForbiddenException, HttpException,
    Injectable,
    InternalServerErrorException,
    UnauthorizedException
} from '@nestjs/common';
import {IException, IFormatExceptionMessage} from "../interfaces/exceptions.interface";

@Injectable()
export class ExceptionsService implements IException {
    UnauthorizedException(data?: IFormatExceptionMessage): void {
        throw new UnauthorizedException(data);
    }

    forbiddenException(data?: IFormatExceptionMessage): void {
        throw new ForbiddenException(data);
    }

    internalServerErrorException(data?: IFormatExceptionMessage): void {
        throw new InternalServerErrorException(data);
    }

    httpException(data?: IFormatExceptionMessage): void {
        throw new HttpException(data.message, data.status);
    }

    badRequestException(data: IFormatExceptionMessage): void {
        throw new BadRequestException(data);
    }
}
