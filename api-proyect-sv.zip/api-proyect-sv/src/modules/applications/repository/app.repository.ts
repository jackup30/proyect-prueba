import {
  DatabaseRepository,
  FindAndCountAll,
} from '../../../shared/interfaces/database-repository.interface';
import { InjectModel } from '@nestjs/sequelize';
import { Op } from 'sequelize';
import { MESSAGE } from '../../../shared/constants/constant';
import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import {
  INTERNAL_ERROR_OPERATION,
  NOT_FOUND_OPERATION,
} from '../../../shared/utils/status-codes';
import { Apps } from '../models/entities/app.entity';
import { Comments } from '../models/entities/comment.entity';
@Injectable()
export class AppsRepository implements DatabaseRepository<Apps> {
  constructor(@InjectModel(Apps) private appModel: typeof Apps) {}

  async create(payload: Apps): Promise<Apps> {
    try {
      const count = await this.appModel.count({
        where: { app_name: payload.app_name },
      });
      if (count > 0) {
        throw new HttpException(MESSAGE.EXISTS.APP_NAME, HttpStatus.FOUND);
      }
      return await payload.save();
    } catch (error) {
      throw error;
    }
  }

  async destroy(id: string): Promise<Apps> {
    try {
      const app = await this.appModel.findByPk<Apps>(id);
      app.deletedAt = new Date();
      return await app.save();
    } catch (error) {
      throw error;
    }
  }

  async findAll(
    limit: number,
    offset: number,
    keyword: string,
  ): Promise<FindAndCountAll<Apps>> {
    try {
      let condition =
        keyword && keyword != undefined
          ? { app_category_id: { [Op.like]: `%${keyword}%` } }
          : null;
    
      if (keyword==" " || keyword == 'undefined' || keyword==null) {
        return await this.appModel.findAndCountAll({
          limit,
          offset,
          include: {
            model: Comments,
            attributes:['comment_text']
        }
        });
      } else if (keyword !=null || keyword != " " ) {
        return await this.appModel.findAndCountAll({
          where: [{ app_category_id: keyword}],
          limit,
          offset,
          include: {
            model: Comments,
            attributes:['comment_text']
        }
        });
      }
    } catch (error) {
      throw error;
    }
  }

  async findOne(id: string): Promise<Apps> {
    try {
      return await this.appModel.findOne({
        where: { app_id: id },
      });
    } catch (error) {
      throw error;
    }
  }
  async update(id: string, payload: Apps): Promise<Apps> {
    try {
      const app = await this.appModel.findByPk<Apps>(id);
      await this.appModel.update(
        { payload },
        {
          where: { app_id: id },
        },
      );
      return app;
    } catch (error) {
      throw error;
    }
  }
}
