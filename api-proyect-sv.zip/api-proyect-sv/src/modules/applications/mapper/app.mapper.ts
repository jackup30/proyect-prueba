import {Mapper} from "../../../shared/utils/mapper";
import { AppDto } from "../models/dto/app.dto";
import { Apps } from "../models/entities/app.entity";

export class AppMapper extends Mapper<AppDto, Apps> {
    mapFrom(param: AppDto): Apps {
        const app = new Apps();
        app.app_name = param.app_name;
        app.app_description = param.app_description;
        app.app_price = param.app_price;
        app.app_category_id = param.app_category_id;
        app.app_image = param.app_image;
        app.app_status = param.app_status;
        return app;
    }
}