import { Module } from '@nestjs/common';
import {SequelizeModule} from "@nestjs/sequelize";
import { ExceptionsModule } from 'src/core/exceptions/exceptions.module';
import { LoggerModule } from 'src/core/logger/logger.module';
import {Apps, Comments, QualityApp, Quality, Category} from './models/entities/index.entitity'
import { AppsController } from './controllers/app.controller';
import { AppService } from './services/app.service';
import { AppsRepository } from './repository/app.repository';
@Module({
  imports:[
    SequelizeModule.forFeature([Apps, Comments, QualityApp, Quality, Category]),
    LoggerModule,
    ExceptionsModule
  ], 
  providers:[AppService, AppsRepository],
  controllers:[AppsController]

})
export class ApplicationModule {}
