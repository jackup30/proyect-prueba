import {
    Column,
    Model,
    Table,
    HasMany,
    DataType,
    BelongsTo,
    ForeignKey
  } from 'sequelize-typescript';
  import { UUIDV4 } from 'sequelize';
import { QualityApp } from './qualityApp.entity';
  @Table({
    modelName: 'quality',
    timestamps: true,
    deletedAt: true,
  })


export class Quality extends Model {
   
    @Column({
        type: DataType.UUID,
        defaultValue: UUIDV4,
        primaryKey: true,
      })
      quality_id: string;
      @Column({
        type: DataType.INTEGER,
        allowNull: false,
      })
      quality_number:number;
      

      @HasMany(() => QualityApp)
      qualitiesApps: QualityApp[]
 }