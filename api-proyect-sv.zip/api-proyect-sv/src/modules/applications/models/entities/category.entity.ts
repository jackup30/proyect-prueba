import {
    Column,
    Model,
    Table,
    HasMany,
    DataType,
    BelongsTo,
    ForeignKey,
    HasOne,
  } from 'sequelize-typescript';
  import { UUIDV4 } from 'sequelize';
import { Apps } from './app.entity';

  @Table({
    modelName: 'category',
    timestamps: true
  })
  export class Category extends Model {
    @Column({
        type: DataType.UUID,
        defaultValue: UUIDV4,
        primaryKey: true,
      })
      category_id: string;

      @Column({
        type: DataType.STRING,
        allowNull: false,
      })
      category_name: string;

      @Column({
        type: DataType.BOOLEAN,
        allowNull: false,
      })
      category_status: boolean;
      
      @HasOne(() => Apps)
      app: Apps;
   }