import {
  Column,
  Model,
  Table,
  HasMany,
  DataType,
  BelongsTo,
  ForeignKey,
} from 'sequelize-typescript';
import { UUIDV4 } from 'sequelize';
import { Apps } from './app.entity';
import { Quality } from './quality.entity';

@Table({
  modelName: 'qualityApp',
  timestamps: true,
  deletedAt: true,
})
export class QualityApp extends Model {
  @Column({
    type: DataType.UUID,
    defaultValue: UUIDV4,
    primaryKey: true,
  })
  qa_id: string;

  @ForeignKey(() => Apps)
  @Column({
    type: DataType.UUID,
    allowNull: false,
  })
  qa_app_id: string;

  @ForeignKey(() => Quality)
  @Column({
    type: DataType.UUID,
    allowNull: false,
  })
  qa_quality_id: string;

  @BelongsTo(() => Apps)
  app: Apps;

  @BelongsTo(() => Quality)
  quality: Quality
}
