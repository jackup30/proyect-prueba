import {
    Column,
    Model,
    Table,
    HasMany,
    DataType,
    BelongsTo,
    ForeignKey,
  } from 'sequelize-typescript';
  import { UUIDV4 } from 'sequelize';
import { Comments } from './comment.entity';
import { QualityApp } from './qualityApp.entity';
import { Category } from './category.entity';


@Table({
    modelName: 'apps',
    timestamps: true,
    deletedAt: true,
  })

  export class Apps extends Model{ 
    @Column({
      type: DataType.UUID,
      defaultValue: UUIDV4,
      primaryKey: true,
    })
    app_id: string;
    @Column({
      type: DataType.STRING,
      allowNull: false,
    })
    app_name:string;
    @Column({
      type: DataType.STRING,
      allowNull: false,
    })
    app_image: string;
    @Column({
      type: DataType.STRING,
      allowNull: false,
    })
    app_description:string;
    @Column({
      type: DataType.FLOAT,
      allowNull: false,
    })
    app_price: number;

    @ForeignKey(() => Category)
    @Column({
      type: DataType.STRING,
      allowNull: false,
    })
    app_category_id: string;

    @Column({
      type: DataType.BOOLEAN,
      allowNull: false,
    })
    app_status: boolean;

    @HasMany(() => Comments)
    comments: Comments[]

    @HasMany(() => QualityApp)
    qualities: QualityApp[]

    @BelongsTo(() => Category)
    category: Category;
    
  }