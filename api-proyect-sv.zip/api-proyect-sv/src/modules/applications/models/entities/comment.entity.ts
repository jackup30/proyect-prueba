import {
  Column,
  Model,
  Table,
  HasMany,
  DataType,
  BelongsTo,
  ForeignKey,
} from 'sequelize-typescript';
import { UUIDV4 } from 'sequelize';
import { Apps } from './app.entity';

@Table({
  modelName: 'comments',
  timestamps: true,
  deletedAt: true,
})
export class Comments extends Model {
  @Column({
    type: DataType.UUID,
    defaultValue: UUIDV4,
    primaryKey: true,
  })
  comment_id: string;

  @ForeignKey(() => Apps)
  @Column({
    type: DataType.UUID,
    allowNull: false,
  })
  comment_app_id: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  comment_text: string;

  @BelongsTo(() => Apps)
  app: Apps;
}
