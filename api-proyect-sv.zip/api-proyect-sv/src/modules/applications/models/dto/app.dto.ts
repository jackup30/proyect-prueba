
import {IsBoolean, IsDecimal, isEmpty, IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, IsArray} from "class-validator";
import {PartialType} from "@nestjs/mapped-types";

export class AppDto {
    @IsString()
    @IsOptional()
    app_id?: string;

    @IsString()
    @IsNotEmpty()
    app_name:string;

    @IsString()
    app_image:string;

    @IsString()
    app_description:string;

    @IsDecimal()
    @IsNotEmpty()
    app_price: number;

    @IsBoolean()
    @IsNotEmpty()
    app_status: boolean;

    @IsString()
    @IsNotEmpty()
    app_category_id: string;
}