import {
    BadRequestException,
    Body,
    Controller,
    Delete,
    Get,
    Param,
    Post,
    Put,
    Query,
  } from '@nestjs/common';
  import { QueryParams } from '../../../shared/interfaces/query-params.interface';
  import { ExceptionsService } from '../../../core/exceptions/exceptions.service';
  import {
    INTERNAL_ERROR_OPERATION,
    NOT_FOUND_OPERATION,
  } from '../../../shared/utils/status-codes';

  import {LoggerService} from "../../../core/logger/logger.service";

  import { AppDto } from '../models/dto/app.dto';
  import { AppService } from '../services/app.service';
  @Controller('apps')
  export class AppsController {
    constructor(
      private readonly appService: AppService,
      private readonly exceptionService: ExceptionsService,
      private readonly logger: LoggerService,
    ) {}
  
    @Get()
    async getAllApp(@Query() params: QueryParams) {
      try {
        return await this.appService.getAllApp(params);
      } catch (e) {
        if (e instanceof BadRequestException) {
          this.exceptionService.badRequestException(NOT_FOUND_OPERATION);
        } else {
          this.exceptionService.badRequestException(INTERNAL_ERROR_OPERATION);
        }
      }
      
    }
  
    @Get('/:id')
    async getAppById(@Param('id') id: string) {
      try {
        return await this.appService.getAppById(id);
      } catch (e) {
        if (e instanceof BadRequestException) {
          this.exceptionService.badRequestException(NOT_FOUND_OPERATION);
        } else {
          this.exceptionService.badRequestException(INTERNAL_ERROR_OPERATION);
        }
      }
    }
  
    @Post()
    async createApp(@Body() payload: AppDto) {
      try {
      return await this.appService.createApp(payload);
    } catch (e) {
      this.logger.error(INTERNAL_ERROR_OPERATION.message, e.toString(), "createProduct");
      this.exceptionService.httpException(e);
  }
    }
  
    @Put('/:id')
    async updateEnterpice(@Param('id') id: string, payload: AppDto) {
      return await this.appService.updateApp(id, payload);
    }
  
    @Delete('/:id')
    async disableApp(@Param('id') id: string) {
      return await this.appService.deleteApp(id);
    }
  }
  