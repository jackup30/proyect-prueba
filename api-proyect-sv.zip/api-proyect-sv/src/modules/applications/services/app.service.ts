import { Injectable } from '@nestjs/common';
import {LoggerService} from "../../../core/logger/logger.service";
import {ExceptionsService} from "../../../core/exceptions/exceptions.service";
import { ERROR_OPERATION, NOT_FOUND_OPERATION } from 'src/shared/utils/status-codes';
import { QueryParams } from 'src/shared/interfaces/query-params.interface';
import { Pagination } from 'src/shared/interfaces/pagination.interface';
import { getOffsetAndLimit } from 'src/shared/utils/Utils';
import { PaginationConvert } from 'src/shared/utils/pagination-convert';
import { IQueryApp } from '../interfaces/app.interface';
import { AppDto } from '../models/dto/app.dto';
import { AppMapper } from '../mapper/app.mapper';
import { AppsRepository } from '../repository/app.repository';
import { Apps } from '../models/entities/app.entity';

@Injectable()
export class AppService implements IQueryApp { 
    private appMapper: AppMapper;
    constructor(
        private readonly repository: AppsRepository,
        private readonly logger: LoggerService,
        private readonly exceptionService: ExceptionsService
    ){
        this.appMapper = new AppMapper();
        this.logger.log("Apps", "Initialize");
    }
   
  
    async createApp(payload: AppDto): Promise<Apps> {
        try {
            const entity = this.appMapper.mapFrom(payload);
            this.logger.log("create app on service action", entity.toString());
            return await this.repository.create(entity);
        } catch (error) {
            this.logger.error(ERROR_OPERATION.message, error);
            this.exceptionService.httpException({status: error.code, message: error.message});
        }
    }

    async getAllApp(params: QueryParams): Promise<Pagination<Apps>> {
        try {
            const {page, size,keyword} = params;
            this.logger.log("Apps QueryParams: ", params.toString());
            const {limit, offset} = getOffsetAndLimit(page, size);
            const result = await this.repository.findAll(limit, offset, keyword);
            if(result) {
                this.logger.log("Finded data: ", `${result}`);
                const pagination = new PaginationConvert<Apps>();
                const apps = pagination.convertResponse(result, page, limit);
                this.logger.log("", `${apps}`);
                return apps;
            }
            
        } catch (e) {
            this.logger.error(ERROR_OPERATION.message, e.toString(), "get all apps");
            this.exceptionService.httpException({status: e.code, message: e.message})
        }
    }


    async getAppById(id: string): Promise<Apps> {
        try{
            this.logger.log("Params", `app: ${id} `);
            const app = await this.repository.findOne(id);
            this.logger.log('get app by id', `${app}`);
            if (!app ) this.exceptionService.badRequestException(NOT_FOUND_OPERATION)
            return app ;
        } catch(e){
            this.logger.error(ERROR_OPERATION.message, e.toString(), "get app by id");
            this.exceptionService.httpException({status: e.code, message: e.message})
        }
        
    }


    async updateApp(id: string, payload: AppDto): Promise<Apps> {
        try {
            const entity = this.appMapper.mapFrom(payload);
            this.logger.log("update app action", entity.toString());
            return await this.repository.update(id, entity);
        } catch (e) {
            this.logger.error(ERROR_OPERATION.message, e.toString(), "update app action");
            this.exceptionService.httpException({status: e.code, message: e.message})
        }
    }


    async deleteApp(id: string): Promise<Apps> {
        try {
            const entity = await this.repository.destroy(id);
            this.logger.log("delete app action", entity.toString());
            return entity;
        } catch (e) {
            this.logger.error(ERROR_OPERATION.message, e.toString(), "delete app action");
            this.exceptionService.httpException({status: e.code, message: e.message})
        }
    }
}