import {AppDto} from '../models/dto/app.dto'
import { Apps } from '../models/entities/app.entity';
import {Pagination} from "../../../shared/interfaces/pagination.interface";
import {QueryParams} from "../../../shared/interfaces/query-params.interface";

export interface IQueryApp {
    getAllApp(id: string, params: QueryParams): Promise<Pagination<Apps>>

    getAppById(id: string): Promise<Apps>

    createApp(payload: AppDto): Promise<Apps>

    updateApp(id: string, payload: Partial<AppDto>): Promise<Apps>

    deleteApp(id: string): Promise<Apps>
}