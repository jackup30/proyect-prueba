import {HttpStatus} from "@nestjs/common";
import {IFormatExceptionMessage} from "../../core/interfaces/exceptions.interface";


export const SUCCESSFUL_OPERATION: IFormatExceptionMessage = {
    status: HttpStatus.OK,
    message: 'Operation Successful'
}

export const ERROR_OPERATION: IFormatExceptionMessage = {
    status: HttpStatus.INTERNAL_SERVER_ERROR,
    message: 'Failed to fetch list'
}

export const INTERNAL_ERROR_OPERATION: IFormatExceptionMessage = {
    status: HttpStatus.INTERNAL_SERVER_ERROR,
    message: 'Internal error'
}

export const NOT_FOUND_OPERATION: IFormatExceptionMessage = {
    status: HttpStatus.NOT_FOUND,
    message: 'Record not found'
}

export const NOT_AUTHORIZED: IFormatExceptionMessage = {
    status: HttpStatus.FORBIDDEN,
    message: 'Not authorized'
}