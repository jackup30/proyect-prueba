import {Pagination} from "../interfaces/pagination.interface";
import {FindAndCountAll} from "../interfaces/database-repository.interface";
import {DEFAULT_PAGE} from "../constants/constant";

export class PaginationConvert<T> implements Pagination<T> {
    currentPage: number;
    items: T[];
    totalItems: number;
    totalPages: number;

    convertResponse(data: FindAndCountAll<T>, page: number, limit: number) {
        this.totalItems = data.count;
        this.items = data.rows;
        this.currentPage = page ? +page : DEFAULT_PAGE;
        this.totalPages = Math.ceil(this.totalItems / limit);
        return {
            items: this.items,
            totalItems: this.totalItems,
            totalPages: this.totalPages,
            currentPage: this.currentPage
        };
    }

    toString(): string {
        return `currentPage: ${this.currentPage}, totalItems: ${this.totalItems}, 
        totalPages: ${this.totalPages}, items: ${this.items.toString()}`
    }
}