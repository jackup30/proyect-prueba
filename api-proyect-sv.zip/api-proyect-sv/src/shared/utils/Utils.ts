import {LIMIT_PAGE, OFFSET_PAGE} from "../constants/constant";

export const getOffsetAndLimit = (page: number, size: number): { limit: number, offset: number } => {
    const limit = size ? +size : LIMIT_PAGE;
    const offset = page ?( (page - 1) * limit) : OFFSET_PAGE;
    return {limit, offset};
}