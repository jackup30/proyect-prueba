import {BadRequestException, Body, Delete, Get, Param, Post, Put, Query} from "@nestjs/common";
import {LoggerService} from "../../core/logger/logger.service";
import {ExceptionsService} from "../../core/exceptions/exceptions.service";
import {ISharedService} from "../interfaces/ISharedService";
import {QueryParams} from "../interfaces/query-params.interface";
import {INTERNAL_ERROR_OPERATION, NOT_FOUND_OPERATION} from "../utils/status-codes";

export class ShareControllerClass<R, DTC, DTU> {
    constructor(
        readonly service: ISharedService<R, DTC, DTU>,
        readonly logger: LoggerService,
        readonly exceptionService: ExceptionsService
    ) {
    }

    @Get()
    async getItems(@Query() params: QueryParams) {
        return await this.service.getAll(params);
    }

    @Post()
    async createItem(@Body() item: DTC) {
        try {
            const result = await this.service.createItem(item);
            this.logger.log(`Create Controller`, result.toString());
            return result;
        } catch (e) {
            this.logger.error(INTERNAL_ERROR_OPERATION.message, e.toString(), "createItem");
            this.exceptionService.httpException(e);
        }
    }

    @Get(':id')
    async getItemById(@Param('id') id: string) {
        try {
            return await this.service.getItemById(id);
        } catch (e) {
            if (e instanceof BadRequestException) {
                this.exceptionService.badRequestException(NOT_FOUND_OPERATION);
            } else {
                this.exceptionService.badRequestException(INTERNAL_ERROR_OPERATION);
            }
        }
    }

    @Put(':id')
    async updateItem(@Param('id') id: string, @Body() item: DTU) {
        try {
            this.logger.log('Request Update', item.toString());
            return await this.service.updateItem(id, item);
        } catch (e) {
            this.logger.error(INTERNAL_ERROR_OPERATION.message, e.toString(), "updateProduct");
            this.exceptionService.httpException(e);
        }
    }


    @Delete(':id')
    async deleteItem(@Param('id') id: string) {
        return await this.service.deleteItem(id);
    }
}