

export const LIMIT_PAGE = 20;
export const OFFSET_PAGE = 0;
export const DEFAULT_PAGE = 1;

export const MESSAGE = {
    EXISTS : {
        APP_NAME: "One name already exists"
    }
}