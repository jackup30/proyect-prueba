import {QueryParams} from "./query-params.interface";
import {Pagination} from "./pagination.interface";

export interface ISharedService<RESPONSE, DTC, DTU> {
    getAll(params: QueryParams): Promise<Pagination<RESPONSE>>

    getItemById( id: string): Promise<RESPONSE>

    createItem(item: DTC): Promise<RESPONSE>

    updateItem(id: string, item: Partial<DTU>): Promise<RESPONSE>

    deleteItem(id: string): Promise<RESPONSE>
}