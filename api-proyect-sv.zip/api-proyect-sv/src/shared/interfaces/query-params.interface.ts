import {IsNumber, IsOptional, IsString} from "class-validator";
import {DEFAULT_PAGE, LIMIT_PAGE} from "../constants/constant";

export class QueryParams {
    @IsOptional()
    page?: number = DEFAULT_PAGE;

    @IsOptional()
    size?: number = LIMIT_PAGE;
    @IsString()
    @IsOptional()
    keyword?: string;
    
    toString() {
        return `page: ${this.page} - size: ${this.size}`;
    }
}