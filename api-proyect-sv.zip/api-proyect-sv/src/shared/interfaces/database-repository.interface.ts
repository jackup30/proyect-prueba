export interface DatabaseRepository<T> {
    findAll(limit?: number, offset?: number, keyword?: string): Promise<FindAndCountAll<T>>;

    findOne(paramansId?: string, id?: string): Promise<T>;

    destroy(id: string): Promise<T>;

    create(item: T): Promise<T>;

    update(id: string, item: T): Promise<T>
}


export interface FindAndCountAll<T> {
    rows: T[];
    count: number
}