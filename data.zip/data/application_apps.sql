-- MySQL dump 10.13  Distrib 8.0.30, for macos12 (x86_64)
--
-- Host: 127.0.0.1    Database: application
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apps`
--

DROP TABLE IF EXISTS `apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apps` (
  `app_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `app_description` varchar(255) NOT NULL,
  `app_price` float NOT NULL,
  `app_category_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `app_status` tinyint(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `app_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`app_id`),
  KEY `app_category_id` (`app_category_id`),
  CONSTRAINT `apps_ibfk_1` FOREIGN KEY (`app_category_id`) REFERENCES `categories` (`category_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apps`
--

LOCK TABLES `apps` WRITE;
/*!40000 ALTER TABLE `apps` DISABLE KEYS */;
INSERT INTO `apps` VALUES ('045598f6-6aea-4ae2-a21f-0d4074928572','App5','Juegos5',6.04,'dc983180-61b7-4540-97fe-01f68a03ac30',0,'2022-08-18 16:52:14','2022-08-18 16:52:14','5.webp'),('14865816-5f8b-421a-beb1-e59cae2f8994','App4','Desarrollador 1',6.04,'dc983180-61b7-4540-97fe-01f68a03ac30',0,'2022-08-18 13:13:09','2022-08-18 13:13:09','1.webp'),('18d5a8ca-193f-4f78-9219-61b741c88bdd','App1','Desarrollador 2',2.45,'dc983180-61b7-4540-97fe-01f68a03ac30',0,'2022-08-18 12:56:53','2022-08-18 12:56:53','2.webp'),('19d539a7-eea9-490d-8821-5ac3f5a3d39e','App16','Desarrollador 16',6.04,'dc983180-61b7-4540-97fe-01f68a03ac30',0,'2022-08-18 17:42:44','2022-08-18 17:42:44','16.webp'),('2a697724-327b-4fc8-9a48-b2538d9c5643','App14','Desarrollador 14',6.04,'dc983180-61b7-4540-97fe-01f68a03ac30',0,'2022-08-18 17:31:57','2022-08-18 17:31:57','14.webp'),('3feb5f63-6186-4f66-bab9-9f20d7b8f80a','App15','Desarrollador 15',6.04,'dc983180-61b7-4540-97fe-01f68a03ac30',0,'2022-08-18 17:32:06','2022-08-18 17:32:06','15.webp'),('5e2f1bc3-cc7d-4e8a-baee-886366eed6f3','App13','Desarrollador 13',6.04,'8d91ed9f-fb6b-4203-a09f-25029b2598b6',0,'2022-08-18 17:31:11','2022-08-18 17:31:11','13.webp'),('66b67097-c09a-4535-ab83-7fd82444bbe0','App18','Desarrollador 18',0.4,'8d91ed9f-fb6b-4203-a09f-25029b2598b6',0,'2022-08-18 17:43:23','2022-08-18 17:43:23','18.webp'),('6d1cc5aa-6c42-45a8-86a9-5a46adefd862','App8','Juegos8',6.04,'8d91ed9f-fb6b-4203-a09f-25029b2598b6',0,'2022-08-18 16:55:07','2022-08-18 16:55:07','8.webp'),('7170f508-4c06-4b0b-b5cc-050e537df1b9','App3','Desarrollador 3',5.16,'8d91ed9f-fb6b-4203-a09f-25029b2598b6',0,'2022-08-18 13:12:57','2022-08-18 13:12:57','3.webp'),('7b894278-fd34-4790-bcf1-87f46f0102f1','App10','Juegos10',6.04,'8d91ed9f-fb6b-4203-a09f-25029b2598b6',0,'2022-08-18 16:55:33','2022-08-18 16:55:33','10.webp'),('95196803-b94a-4113-836a-c422de255548','App17','Desarrollador 17',6.04,'8d91ed9f-fb6b-4203-a09f-25029b2598b6',0,'2022-08-18 17:42:56','2022-08-18 17:42:56','17.webp'),('99323805-cbd8-481b-801f-c406d575de67','App9','Juegos9',6.04,'2a23088a-ac4a-443d-9bbf-c11e9198949e',0,'2022-08-18 16:55:15','2022-08-18 16:55:15','9.webp'),('a01a9d53-891e-469b-9df4-c26feecce986','App6','Juegos6',6.04,'2a23088a-ac4a-443d-9bbf-c11e9198949e',0,'2022-08-18 16:52:35','2022-08-18 16:52:35','6.webp'),('a0da5dcc-5dc2-4d8e-8365-dd188ba414ba','App2','Desarrollador 4',3.16,'2a23088a-ac4a-443d-9bbf-c11e9198949e',0,'2022-08-18 13:12:43','2022-08-18 13:12:43','4.webp'),('c24444cf-3011-4cd6-ac9a-381c7b5ae4db','App11','Desarrollador 11',6.04,'2a23088a-ac4a-443d-9bbf-c11e9198949e',0,'2022-08-18 17:30:48','2022-08-18 17:30:48','11.webp'),('c56d4eb2-c866-4ff1-b2d8-f9be5e14e6f9','App7','Juegos7',0.04,'2a23088a-ac4a-443d-9bbf-c11e9198949e',0,'2022-08-18 16:54:21','2022-08-18 16:54:21','7.webp'),('fb6ba883-f842-42a2-b611-adc862bb3f8a','App12','Desarrollador 12',6.04,'2a23088a-ac4a-443d-9bbf-c11e9198949e',0,'2022-08-18 17:31:00','2022-08-18 17:31:00','12.webp');
/*!40000 ALTER TABLE `apps` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 20:47:57
